package com.example.runtime;

public interface Reloadable {
    void reload(RuntimeConfig cfg);
}
