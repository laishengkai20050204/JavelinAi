package com.example.api.dto;

public record ChatMessage(String role, String content) {}