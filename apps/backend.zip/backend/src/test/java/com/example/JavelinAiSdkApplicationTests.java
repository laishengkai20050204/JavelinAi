package com.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(properties = "ai.memory.storage=in-memory")
class JavelinAiSdkApplicationTests {

    @Test
    void contextLoads() {
    }

}
